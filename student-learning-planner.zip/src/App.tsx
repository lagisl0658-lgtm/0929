import { useState, useEffect } from 'react';
import { Calendar, BookOpen, Plus, Trash2, Clock } from 'lucide-react';

type Course = {
  id: string;
  name: string;
  progress: number;
};

type Session = {
  id: string;
  label: string;
  time: string;
};

const DEFAULT_SESSIONS: Session[] = [
  { id: '1', label: '第1節', time: '08:10-09:00' },
  { id: '2', label: '第2節', time: '09:10-10:00' },
  { id: '3', label: '第3節', time: '10:10-11:00' },
  { id: '4', label: '第4節', time: '11:10-12:00' },
  { id: 'lunch', label: '午休', time: '12:00-13:00' },
  { id: '5', label: '第5節', time: '13:00-13:50' },
  { id: '6', label: '第6節', time: '14:00-14:50' },
];

const daysOfWeek = ['週一', '週二', '週三', '週四', '週五'];

export default function App() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [newCourseName, setNewCourseName] = useState('');
  const [sessions, setSessions] = useState<Session[]>(DEFAULT_SESSIONS);
  
  // Schedule state: day -> sessionId -> courseName
  const [schedule, setSchedule] = useState<Record<string, Record<string, string>>>(
    daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: {} }), {})
  );

  // Load from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('student-planner-data');
    if (saved) {
      const data = JSON.parse(saved);
      setCourses(data.courses || []);
      setSessions(data.sessions || DEFAULT_SESSIONS);
      setSchedule(data.schedule || daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: {} }), {}));
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('student-planner-data', JSON.stringify({ courses, sessions, schedule }));
  }, [courses, sessions, schedule]);

  const addCourse = () => {
    if (!newCourseName.trim()) return;
    setCourses([...courses, { id: Date.now().toString(), name: newCourseName, progress: 0 }]);
    setNewCourseName('');
  };

  const updateProgress = (id: string, progress: number) => {
    setCourses(courses.map(c => c.id === id ? { ...c, progress: Math.min(100, Math.max(0, progress)) } : c));
  };

  const deleteCourse = (id: string) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const updateSession = (id: string, field: 'label' | 'time', value: string) => {
    setSessions(sessions.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6 md:p-12">
      <header className="mb-12">
        <h1 className="text-3xl font-bold tracking-tight">學生學習規劃工具</h1>
        <p className="text-slate-500 mt-2">有效率地管理您的學習時間與進度</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Plus className="w-5 h-5 text-indigo-600" /> 新增科目
          </h2>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={newCourseName}
              onChange={(e) => setNewCourseName(e.target.value)}
              className="flex-1 p-2 border border-slate-300 rounded-lg text-sm"
              placeholder="例如: 數學"
            />
            <button onClick={addCourse} className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700">新增</button>
          </div>
        </div>

        <div className="md:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" /> 學習清單
          </h2>
          <ul className="space-y-4">
            {courses.map(course => (
              <li key={course.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                <span className="font-medium">{course.name}</span>
                <div className="flex items-center gap-4">
                  <input 
                    type="number"
                    value={course.progress}
                    onChange={(e) => updateProgress(course.id, parseInt(e.target.value))}
                    className="w-16 p-1 border border-slate-300 rounded text-center text-sm"
                  /> %
                  <button onClick={() => deleteCourse(course.id)} className="text-slate-400 hover:text-red-500">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 overflow-x-auto">
        <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-600" /> 課表
        </h2>
        <table className="w-full text-sm">
          <thead>
            <tr>
              <th className="p-2 border">節次 / 時間</th>
              {daysOfWeek.map(day => <th key={day} className="p-2 border">{day}</th>)}
            </tr>
          </thead>
          <tbody>
            {sessions.map(session => (
              <tr key={session.id} className={session.id === 'lunch' ? 'bg-slate-100' : ''}>
                <td className="p-2 border font-medium">
                  <input 
                    type="text"
                    value={session.label}
                    onChange={(e) => updateSession(session.id, 'label', e.target.value)}
                    className="w-full font-bold p-1 bg-transparent"
                  />
                  <input 
                    type="text"
                    value={session.time}
                    onChange={(e) => updateSession(session.id, 'time', e.target.value)}
                    className="w-full text-xs text-slate-500 p-1 bg-transparent"
                  />
                </td>
                {daysOfWeek.map(day => (
                  <td key={day} className="p-2 border">
                    <input 
                      type="text"
                      value={schedule[day][session.id] || ''}
                      onChange={(e) => updateSchedule(day, session.id, e.target.value)}
                      className="w-full p-1 bg-transparent"
                      placeholder={session.id === 'lunch' ? '休息時間' : '輸入科目'}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
